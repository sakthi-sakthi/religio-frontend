import Navbar from "./includes/Navbar";
import Sidemenubar from "./includes/Sidemenubar";
import Main from "./includes/Main";
import Footer from "./includes/Footer";
import "./scss/style.scss";
import ReguserCreate from "./pages/UsersList/ReguserCreate";


function UserCreate() {
    return (
        <div className="container-scroller">
            <Navbar />
            <div className="container-fluid page-body-wrapper">
            <Sidemenubar />
                <div className="main-panel">
                   <ReguserCreate/>
                    <Footer/>
                </div>
            </div>
        </div>
    );
}

export default UserCreate;