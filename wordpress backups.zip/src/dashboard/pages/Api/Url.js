const AppUrl = "https://religioapp.cristoerp.com";
export default AppUrl;
