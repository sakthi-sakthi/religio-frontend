const ApiUrl = "https://religioapp.cristoerp.com/api";
export default ApiUrl;
