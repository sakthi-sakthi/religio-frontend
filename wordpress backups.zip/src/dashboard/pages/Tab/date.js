export const makeJsDate = (date='20-02-2020')=>{
console.log('##############')
}